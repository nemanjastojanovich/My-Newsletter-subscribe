Note: This repository is auto-generated, and does not accept pull requests.

To make changes or open issues for this SDK, use the [code generation repository](https://github.com/mailchimp/mailchimp-client-lib-codegen).
