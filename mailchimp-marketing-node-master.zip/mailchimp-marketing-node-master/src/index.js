var ApiClient = require('./ApiClient');

module.exports = ApiClient.instance;
